-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Aug 22, 2020 at 10:43 PM
-- Server version: 5.7.26
-- PHP Version: 7.2.18

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ecom_store`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

DROP TABLE IF EXISTS `admins`;
CREATE TABLE IF NOT EXISTS `admins` (
  `admin_id` int(10) NOT NULL AUTO_INCREMENT,
  `admin_name` varchar(255) NOT NULL,
  `admin_email` varchar(255) NOT NULL,
  `admin_pass` varchar(255) NOT NULL,
  `admin_image` text NOT NULL,
  `admin_country` text NOT NULL,
  `admin_about` text NOT NULL,
  `admin_contact` varchar(255) NOT NULL,
  `admin_job` varchar(255) NOT NULL,
  PRIMARY KEY (`admin_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`admin_id`, `admin_name`, `admin_email`, `admin_pass`, `admin_image`, `admin_country`, `admin_about`, `admin_contact`, `admin_job`) VALUES
(1, 'Amjad Ahmed', 'ahmed@gmail.com', 'amj123', 'amjad.jpg', 'Pakistan', ' Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolorem deleniti harum odio, aliquam ipsum impedit quisquam rem natus tempore aut officia suscipit reiciendis quas consequatur soluta maiores ad voluptas velit?', '03123456789', 'Accountant'),
(2, 'Kashif Ali', 'ali@gmail.com', 'kshf123', 'kashif.jpeg', 'USA', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Consequuntur tempora atque doloribus? Dolore incidunt delectus corrupti dignissimos, itaque aperiam laborum aliquid a officia, veritatis porro commodi obcaecati ex, recusandae quod.', '123456789', 'Developer'),
(3, 'Hammad Amir', 'hammad@gmail.com', 'amir123', 'amir.jpg', 'Pakistan', 'Work from home', '123456789', 'Contractor');

-- --------------------------------------------------------

--
-- Table structure for table `boxes_section`
--

DROP TABLE IF EXISTS `boxes_section`;
CREATE TABLE IF NOT EXISTS `boxes_section` (
  `box_id` int(10) NOT NULL AUTO_INCREMENT,
  `box_title` text NOT NULL,
  `box_desc` text NOT NULL,
  PRIMARY KEY (`box_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `boxes_section`
--

INSERT INTO `boxes_section` (`box_id`, `box_title`, `box_desc`) VALUES
(1, ' BEST OFFER ', 'Save 30% on  every purchase.\r\nSo, Hurry Up! Roll up the sleeves and avail this offer.'),
(2, 'Limited time Offer', 'Save up to 30% on every PC purchase.\r\nSo, don\'t miss the golden chance and avail this offer as soon as possible as the offer is valid only for the limited time.'),
(3, '   100% ORIGINAL   ', 'All products are 100% original with money back guarantee from our valuable trusted manufacturers.\r\n');

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

DROP TABLE IF EXISTS `cart`;
CREATE TABLE IF NOT EXISTS `cart` (
  `p_id` int(10) NOT NULL,
  `ip_add` varchar(255) NOT NULL,
  `qty` int(10) NOT NULL,
  `p_price` varchar(255) NOT NULL,
  `size` text NOT NULL,
  PRIMARY KEY (`p_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
CREATE TABLE IF NOT EXISTS `categories` (
  `cat_id` int(10) NOT NULL AUTO_INCREMENT,
  `cat_title` text NOT NULL,
  `cat_top` text NOT NULL,
  `cat_image` text NOT NULL,
  PRIMARY KEY (`cat_id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`cat_id`, `cat_title`, `cat_top`, `cat_image`) VALUES
(1, ' small ', 'yes', 'cat1.jpg'),
(2, 'middle', 'no', 'cat2.jpg'),
(3, 'large', 'no', 'cat3.jpg'),
(4, 'other', 'yes', 'cat4.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `coupons`
--

DROP TABLE IF EXISTS `coupons`;
CREATE TABLE IF NOT EXISTS `coupons` (
  `coupon_id` int(100) NOT NULL AUTO_INCREMENT,
  `product_id` int(100) NOT NULL,
  `coupon_title` varchar(255) NOT NULL,
  `coupon_price` varchar(255) NOT NULL,
  `coupon_code` varchar(255) NOT NULL,
  `coupon_limit` int(100) NOT NULL,
  `coupon_used` int(100) NOT NULL,
  PRIMARY KEY (`coupon_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `coupons`
--

INSERT INTO `coupons` (`coupon_id`, `product_id`, `coupon_title`, `coupon_price`, `coupon_code`, `coupon_limit`, `coupon_used`) VALUES
(1, 25, 'Coupon for Hp laptop', '215', '5451216', 3, 0);

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

DROP TABLE IF EXISTS `customers`;
CREATE TABLE IF NOT EXISTS `customers` (
  `customer_id` int(10) NOT NULL AUTO_INCREMENT,
  `customer_name` varchar(255) NOT NULL,
  `customer_email` varchar(255) NOT NULL,
  `customer_pass` varchar(255) NOT NULL,
  `customer_country` text NOT NULL,
  `customer_city` text NOT NULL,
  `customer_contact` varchar(255) NOT NULL,
  `customer_address` text NOT NULL,
  `customer_image` text NOT NULL,
  `customer_ip` varchar(100) NOT NULL,
  PRIMARY KEY (`customer_id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`customer_id`, `customer_name`, `customer_email`, `customer_pass`, `customer_country`, `customer_city`, `customer_contact`, `customer_address`, `customer_image`, `customer_ip`) VALUES
(2, 'Abc', 'abc@gmail.com', 'abcabc', 'America', 'Washington', '7328728223', 'Washington, America', 'Abdullah Khan.jpeg', '::1'),
(1, 'Asad', 'asad@gmail.com', 'asad123', 'USA', 'New York', '678219812', 'Newyork, USA', 'Director Talal Ashraf.jpeg', '::1');

-- --------------------------------------------------------

--
-- Table structure for table `customer_orders`
--

DROP TABLE IF EXISTS `customer_orders`;
CREATE TABLE IF NOT EXISTS `customer_orders` (
  `order_id` int(10) NOT NULL AUTO_INCREMENT,
  `customer_id` int(10) NOT NULL,
  `due_amount` int(100) NOT NULL,
  `invoice_no` int(100) NOT NULL,
  `qty` int(10) NOT NULL,
  `size` text NOT NULL,
  `order_date` date NOT NULL,
  `order_status` text NOT NULL,
  PRIMARY KEY (`order_id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer_orders`
--

INSERT INTO `customer_orders` (`order_id`, `customer_id`, `due_amount`, `invoice_no`, `qty`, `size`, `order_date`, `order_status`) VALUES
(1, 1, 2400, 1627643586, 2, 'Medium', '2020-08-12', 'Complete'),
(2, 1, 179, 1627643586, 1, '', '2020-08-12', 'pending'),
(3, 1, 300, 1627643586, 1, 'Small', '2020-08-12', 'pending'),
(4, 1, 300, 1627643586, 1, 'Small', '2020-08-12', 'pending'),
(5, 2, 179, 18213711, 1, 'Small', '2020-08-19', 'pending'),
(6, 2, 115, 256560881, 1, 'Small', '2020-08-19', 'pending');

-- --------------------------------------------------------

--
-- Table structure for table `manufacturers`
--

DROP TABLE IF EXISTS `manufacturers`;
CREATE TABLE IF NOT EXISTS `manufacturers` (
  `manufacturer_id` int(10) NOT NULL AUTO_INCREMENT,
  `manufacturer_title` text NOT NULL,
  `manufacturer_top` text NOT NULL,
  `manufacturer_image` text NOT NULL,
  PRIMARY KEY (`manufacturer_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `manufacturers`
--

INSERT INTO `manufacturers` (`manufacturer_id`, `manufacturer_title`, `manufacturer_top`, `manufacturer_image`) VALUES
(1, 'Adil Khan', 'yes', 'image1.jpg'),
(2, 'Maira Yousuf', 'no', 'image2.jpg'),
(3, 'Eliza shah', 'yes', 'image3.jpg'),
(4, 'Shah Meer Zafar', 'no', 'image4.jpg'),
(5, 'Faiza Naz', 'yes', 'image5.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

DROP TABLE IF EXISTS `payments`;
CREATE TABLE IF NOT EXISTS `payments` (
  `payment_id` int(10) NOT NULL AUTO_INCREMENT,
  `invoice_no` int(10) NOT NULL,
  `amount` int(10) NOT NULL,
  `payment_mode` text NOT NULL,
  `ref_no` int(10) NOT NULL,
  `code` int(10) NOT NULL,
  `payment_date` text NOT NULL,
  PRIMARY KEY (`payment_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `payments`
--

INSERT INTO `payments` (`payment_id`, `invoice_no`, `amount`, `payment_mode`, `ref_no`, `code`, `payment_date`) VALUES
(1, 1627643586, 2400, 'Back Code', 2154, 65484, '12/08/2020');

-- --------------------------------------------------------

--
-- Table structure for table `pending_orders`
--

DROP TABLE IF EXISTS `pending_orders`;
CREATE TABLE IF NOT EXISTS `pending_orders` (
  `order_id` int(10) NOT NULL AUTO_INCREMENT,
  `customer_id` int(10) NOT NULL,
  `invoice_no` int(10) NOT NULL,
  `product_id` text NOT NULL,
  `qty` int(10) NOT NULL,
  `size` text NOT NULL,
  `order_status` text NOT NULL,
  PRIMARY KEY (`order_id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pending_orders`
--

INSERT INTO `pending_orders` (`order_id`, `customer_id`, `invoice_no`, `product_id`, `qty`, `size`, `order_status`) VALUES
(1, 1, 1627643586, '26', 2, 'Medium', 'Complete'),
(2, 1, 1627643586, '29', 1, '', 'pending'),
(3, 1, 1627643586, '30', 1, 'Small', 'pending'),
(5, 2, 18213711, '29', 1, 'Small', 'pending'),
(6, 2, 256560881, '28', 1, 'Small', 'pending');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
CREATE TABLE IF NOT EXISTS `products` (
  `product_id` int(10) NOT NULL AUTO_INCREMENT,
  `p_cat_id` int(10) NOT NULL,
  `cat_id` int(10) NOT NULL,
  `manufacturer_id` int(10) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `product_title` text NOT NULL,
  `product_url` text NOT NULL,
  `product_img1` text NOT NULL,
  `product_img2` text NOT NULL,
  `product_img3` text NOT NULL,
  `product_price` int(10) NOT NULL,
  `product_desc` text NOT NULL,
  `product_features` text NOT NULL,
  `product_video` text NOT NULL,
  `product_label` text NOT NULL,
  `product_sale` int(100) NOT NULL,
  `product_keywords` text NOT NULL,
  PRIMARY KEY (`product_id`)
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`product_id`, `p_cat_id`, `cat_id`, `manufacturer_id`, `date`, `product_title`, `product_url`, `product_img1`, `product_img2`, `product_img3`, `product_price`, `product_desc`, `product_features`, `product_video`, `product_label`, `product_sale`, `product_keywords`) VALUES
(20, 3, 3, 1, '2020-08-21 08:53:42', 'Hp laptop', 'product-1', 'HP Laptop-15t.webp', 'HP Laptop-15t2.webp', 'HP Laptop-15t3.jpg', 1500, '<p>As big as your imagination. The immersive, 17\" display allows you to easily create true-to-life visuals with stunning, accurate colors. Customizable performance puts the controls in your hands, and peace of mind features ensure your creations are safe-guarded until you&rsquo;re ready to share them.</p>\r\n<p><em><strong>The power to bring your creations to life</strong></em></p>\r\n<p>The powerful combination of an Intel&reg; Core&trade;</p>\r\n<p>Sometimes bigger is better. Watch your creations come to life in accurate, vibrant color on this massive high definition, micro-edge display.</p>\r\n<p><em><strong>Privacy for your peace of mind</strong></em></p>\r\n<p>Keep it confidential with an unhackable camera shutter and dedicated microphone mute button.</p>', '<p>Windows 10 Home 64</p>\r\n<p>10th Gen Intel&reg; Core&trade; i7 processor</p>\r\n<p>NVIDIA&reg; GeForce&reg; MX330 (4 GB)</p>\r\n<p>16 GB Memory; 1 TB SSD storage</p>\r\n<p>17.3\" diagonal FHD touch display</p>', '                                                                        <iframe width=\"640\" height=\"360\" src=\"https://www.youtube.com/embed/GFvaLRKY9pA\" frameborder=\"0\" allow=\"accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture\" allowfullscreen></iframe>                                                                ', 'sale', 1000, 'Hp laptops, laptop'),
(22, 2, 1, 3, '2020-08-21 08:35:59', 'HP 90W Smart AC Adapter', '-', 'ddapter1.webp', 'adapter2.webp', 'ddapter1.webp', 60, '<p>Provide optimal power and help offset power fluctuations to your HP notebook with a HP 90W Smart AC Adapter. Now available with a new right-angled (90&deg;) connector that reduces cable stress and an optional 4.5mm to 7.4mm conversion dongle. As a replacement or back-up adapter, be prepared with the right connection.</p>', '<p>Compatibility</p>\r\n<p>HP Smart AC Adapters are compatible with all HP Business Notebooks and Tablet PCs NOTE: Not all models are available in all regions.</p>\r\n<p>Power: 90w</p>\r\n<p>Connector: 4.5mm(F)-7.4mm(M) dongle</p>\r\n<p>Dimensions (W X D X H): 4.92 x 1.97 x 1.18 in</p>\r\n<p>Weight: 0.72 lb</p>', '                                                                                                                                        ', 'sale', 50, 'Adapter'),
(23, 2, 1, 4, '2020-08-21 08:54:35', 'HP X3000 Wireless Mouse', '_', 'center_facing.webp', 'Mouse2.webp', 'Mouse3.webp', 12, '<p>Premium HP standards</p>\r\n<p>Stylish, attractive design</p>\r\n<p>No more pulling. No more tugging.</p>\r\n<p>Scroll wheel</p>', '<p>Color: Black; Metallic gray</p>\r\n<p>Buttons: 3 buttons; Scroll wheel</p>\r\n<p>Connector: USB wireless receiver at 27 MHz</p>\r\n<p>Wireless technology: 27MHz wireless technology</p>', '', 'sale', 10, 'Mouse, Wireless mouse'),
(26, 1, 2, 1, '2020-08-21 06:56:37', 'Dell Laptop', 'product-2', 'DELLlaptop1.jpg', 'DELLlaptop3.jpg', 'DELLlaptop2.jpg', 1200, '<p>Crisp gameplay is crucial if you want to play at your best. With a high resolution and refresh rate, on-screen visuals are swift and smooth, while a narrow bezel display delivers edge-to-edge immersion.</p>', '<p>Windows 10 Home 64</p>\r\n<p>10th Gen Intel&reg; Core&trade; i7 processor</p>\r\n<p>NVIDIA&reg; GeForce&reg; GTX 1660 Ti (6 GB)</p>\r\n<p>16 GB memory; 512 GB SSD storage</p>\r\n<p>17.3\" diagonal FHD display</p>', '                                    <iframe width=\"640\" height=\"360\" src=\"https://www.youtube.com/embed/GFvaLRKY9pA\" frameborder=\"0\" allow=\"accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture\" allowfullscreen></iframe>                                ', 'sale', 20, 'Dell laptops, laptop'),
(27, 5, 2, 3, '2020-08-21 06:58:31', 'Apple Elite', 'product-3', 'Apple Elite1.webp', 'Apple Elite2.webp', 'Apple Elite3.webp', 2000, '<p>Designed for the modern mobile professional, the Apple EliteBook 745 delivers enterprise-grade security and manageability along with powerful collaboration features to keep you connected.</p>', '<p>Windows 10 Pro 64</p>\r\n<p>AMD PRO Ryzen-Series processor</p>\r\n<p>8 GB memory; 256 GB SSD storage</p>\r\n<p>14\" diagonal FHD display</p>', '                                    <iframe width=\"640\" height=\"360\" src=\"https://www.youtube.com/embed/GFvaLRKY9pA\" frameborder=\"0\" allow=\"accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture\" allowfullscreen></iframe>                                ', 'new', 1700, 'Apple laptops, laptop'),
(28, 4, 3, 4, '2020-08-21 07:00:17', 'Lenovo elite', 'product-4', 'Lenovo1.webp', 'Lenovo2.webp', 'Lenovo3.webp', 400, '<p>Crystal-clear collaboration</p>\r\n<p>Calls sound crisp and clear with advanced collaboration features like Lenovo Noise Cancellation and an integrated with world-facing microphone. Loud top-firing speakers produce rich sound and collaboration keys help make PC calls productive.</p>', '<p>Windows 10 Home 64</p>\r\n<p>10th Generation Intel&reg; Core&trade; i7 processor</p>\r\n<p>NVIDIA&reg; GeForce RTX&trade; 2060 (6 GB GDDR6 dedicated)</p>\r\n<p>16 GB memory; 1 TB HDD storage; 512 GB SSD storage</p>\r\n<p>17.3\" diagonal FHD display</p>', '                                                                        <iframe width=\"640\" height=\"360\" src=\"https://www.youtube.com/embed/GFvaLRKY9pA\" frameborder=\"0\" allow=\"accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture\" allowfullscreen></iframe>                                                                ', 'sale', 250, 'Lenovo laptop, laptops'),
(29, 2, 3, 3, '2020-08-21 07:02:13', 'HP ENVY Printer', 'product-5', 'printer1.webp', 'printer2.webp', 'printer3.webp', 179, '<p>Print, Scan, Copy, Web, Photo</p>\r\n<p>Print speed ISO: Up to 14 ppm black, up to 9 ppm color</p>\r\n<p>Go from memory card to photo printout with ease</p>\r\n<p>Instant Ink ready; High yield ink available</p>', '<h3 style=\"margin: 0px; padding: 0px; direction: ltr; font-family: HPSimplifiedLight; font-weight: normal; color: #222222; text-rendering: optimizelegibility; line-height: 40px; font-size: 24px; border: 0px; box-sizing: border-box;\">HP OfficeJet Pro Printers</h3>\r\n<p style=\"margin: 0px 0px 1em; padding: 0px; direction: ltr; font-family: HPSimplifiedLight; font-size: 18px; line-height: 26px; text-rendering: optimizelegibility; border: 0px; color: #767676; box-sizing: border-box;\">Print professional color for up to 50% lower cost per page than lasers,&nbsp;and use smart touch features to finish jobs fast.</p>', '                                    <iframe width=\"640\" height=\"360\" src=\"https://www.youtube.com/embed/GFvaLRKY9pA\" frameborder=\"0\" allow=\"accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture\" allowfullscreen></iframe>                                ', 'sale', 215, 'Printer, hp color, laserjet'),
(31, 3, 2, 2, '2020-08-21 08:52:12', 'HP Envvy', 'product-6', 'Hpenvy3.jpg', 'Hpenvy1.jpg', 'Hpenvy2.jpg', 600, '<p>Envy745 G6 with AMD Ryzen 3 PRO 3300U processor + Integrated AMD Radeon Vega Graphics ( 5VU36AV )</p>\r\n<p>Envy 745 G6 with AMD Ryzen 5 PRO 3500U processor + Integrated AMD Radeon Vega Graphics ( 5VU37AV )</p>\r\n<p>Envy 745 G6 with AMD Ryzen 7 PRO 3700U processor + Integrated AMD Radeon Vega Graphics ( 5VU38AV )</p>', '<p>Windows 10 Home 64</p>\r\n<p>10th Gen Intel&reg; Core&trade; i7 processor</p>\r\n<p>NVIDIA&reg; GeForce&reg; GTX 1660 Ti (6 GB)</p>\r\n<p>16 GB memory; 512 GB SSD storage</p>', '                                    <iframe width=\"640\" height=\"360\" src=\"https://www.youtube.com/embed/GFvaLRKY9pA\" frameborder=\"0\" allow=\"accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture\" allowfullscreen></iframe>                                ', 'new', 450, 'Hp laptops, laptop'),
(37, 2, 4, 5, '2020-08-21 09:05:45', 'HP Wireless Mouse 200', '_', 'wireless mouse1.webp', 'wireless mouse3.webp', 'wirelessMouse2.webp', 15, '<p>Wireless convenience</p>\r\n<p>Built to last</p>\r\n<p>Contoured comfort</p>\r\n<p>Good to go</p>\r\n<p>Reliability you can count on</p>', '<p>Color</p>\r\n<p>Pike silver</p>\r\n<p>Compatibility</p>\r\n<p>Available USB port.</p>\r\n<p>Minimum system requirements</p>\r\n<p>Windows 7 and above,[2]</p>\r\n<p>[2] Windows&reg; is either registered trademark or trademark of Microsoft Corporation in the United States and/or other countries. All other trademarks are the property of their respective owners. Actual product may vary from image shown:</p>\r\n<p>Mac OS 10.x and above, and Chrome OS.</p>\r\n<p>Dimensions (W X D X H): 3.74 x 2.3 x 1.34 in</p>\r\n<p>Weight: 0.17 lb</p>', '', 'sale', 13, 'Mouse, Wireless mouse');

-- --------------------------------------------------------

--
-- Table structure for table `product_categories`
--

DROP TABLE IF EXISTS `product_categories`;
CREATE TABLE IF NOT EXISTS `product_categories` (
  `p_cat_id` int(10) NOT NULL AUTO_INCREMENT,
  `p_cat_title` text NOT NULL,
  `p_cat_top` text NOT NULL,
  `p_cat_image` text NOT NULL,
  PRIMARY KEY (`p_cat_id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product_categories`
--

INSERT INTO `product_categories` (`p_cat_id`, `p_cat_title`, `p_cat_top`, `p_cat_image`) VALUES
(1, 'dell laptops', 'yes', 'p_cat_1.jpg'),
(2, 'hard drives\r\n', 'no', 'p_cat_2.jpg'),
(3, 'hp laptops', 'yes', 'p_cat_3.jpg'),
(4, 'lenovo laptops', 'no', 'p_cat_4.jpg'),
(5, 'apple laptops', 'no', 'p_cat_5.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `slider`
--

DROP TABLE IF EXISTS `slider`;
CREATE TABLE IF NOT EXISTS `slider` (
  `slide_Id` int(10) NOT NULL AUTO_INCREMENT,
  `slide_name` varchar(255) NOT NULL,
  `slide_image` text NOT NULL,
  `slide_url` varchar(255) NOT NULL,
  PRIMARY KEY (`slide_Id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `slider`
--

INSERT INTO `slider` (`slide_Id`, `slide_name`, `slide_image`, `slide_url`) VALUES
(1, 'slide number 1', 'Slide 1.webp', 'http://localhost/comp-ecommerce-website/m-dev-store/index.php'),
(2, 'slide number 2', 'Slide 2.webp', 'http://localhost/comp-ecommerce-website/m-dev-store/shop.php'),
(3, 'slide number 3', 'Slide 3.webp', 'http://localhost/comp-ecommerce-website/m-dev-store/contact.php'),
(5, 'slide number 4', 'Slide 4.webp', 'abc.com');

-- --------------------------------------------------------

--
-- Table structure for table `terms`
--

DROP TABLE IF EXISTS `terms`;
CREATE TABLE IF NOT EXISTS `terms` (
  `term_id` int(10) NOT NULL AUTO_INCREMENT,
  `term_title` varchar(100) NOT NULL,
  `term_link` varchar(100) NOT NULL,
  `term_desc` text NOT NULL,
  PRIMARY KEY (`term_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `terms`
--

INSERT INTO `terms` (`term_id`, `term_title`, `term_link`, `term_desc`) VALUES
(1, 'Term & conditions', 'termLink', '<p>Please read these Terms and Conditions (\"Terms\", \"Terms and Conditions\") carefully before using the http://www.mdevstore.com (change this) website. Your access to and use of the Service is conditioned on your acceptance of and compliance with these Terms. These Terms apply to all visitors, users and others who access or use the Service. By accessing or using the Service you agree to be bound by these Terms. If you disagree with any part of the terms then you may not access the Service. Purchases If you wish to purchase any product or service made available through the Service (\"Purchase\"), you may be asked to supply certain information relevant to your Purchase including, without limitation, your … The Purchases section is for businesses that sell online (physical or digital). For the full disclosure section, create your own Terms and Conditions. Subscriptions Some parts of the Service are billed on a subscription basis (\"Subscription(s)\"). You will be billed in advance on a recurring ... Our Service allows you to post, link, store, share and otherwise make available certain information, text, graphics, videos, or other material (\"Content\"). You are responsible for the … The Content section is for businesses that allow users to create, edit, share, make content on their websites or apps. For the full disclosure section, create your own Terms and Conditions. Links To Other Web Sites Our Service may contain links to third-party web sites or services that are not owned or controlled by MDEV Store. MDEV Store has no control over, and assumes no responsibility for, the content, privacy policies, or practices of any third party web sites or services. You further acknowledge and agree thatMDEV Store shall not be responsible or liable, directly or indirectly, for any damage or loss caused or alleged to be caused by or in connection with use of or reliance on any such content, goods or services available on or through any such web sites or services. Changes We reserve the right, at our sole discretion, to modify or replace these Terms at any time. If a revision is material we will try to provide at least 30 days\' notice prior to any new terms taking effect. What constitutes a material change will be determined at our sole discretion. Contact Us If you have any questions about these Terms, please contact us..</p>'),
(2, 'Refund', 'refundLink', 'Return & Refund Policy\r\nThanks for shopping at MDEV Store.\r\nIf you are not entirely satisfied with your purchase, we\'re here to help.\r\nReturns\r\nYou have 30 calendar days to return an item from the date you received it.\r\nTo be eligible for a return, your item must be unused and in the same condition that you received it.\r\nYour item must be in the original packaging.\r\nYour item needs to have the receipt or proof of purchase.\r\n'),
(3, 'Promotion and terms', 'promoLink', 'Workplace promotions may result from a new job opening, or from an upward reclassification of an existing position in the company. Factors that should be considered when determining the eligibility of an employee’s promotion include performance levels, skills, education, relevant experience and professional development.\r\nIn most companies, performance appraisal systems are utilized to evaluate employees generally, and for promotions. When an employee from within the company is involved, he should demonstrate current capacity to perform the duties at the next highest rank. In some companies, depending on the type of job involved, the hiring supervisor might be mandated to evaluate the employee’s performance ability in the new position for several months.'),
(5, 'Rules', 'rules', 'When you send out order confirmations, make sure to include all of the product details to re-assure the buyer that they\'ve selected properly. If I accidentally ordered the size 9 instead of size 8, I want to be able to fix it before the package arrives.\r\nReplicate this experience for your own customers, rather than leaving them in the dark (or, worse, crowding up your customer service dept. with e-mails that could have been answered in an automated fashion).');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
